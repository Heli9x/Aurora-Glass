import json
import os
import shutil
from pathlib import Path

CONFIG_FILENAME = '.filey-config.json'
DEFAULT_NAME = 'Filey'

ALLOWED_KEYS = {'platform_name', 'storage_dir', 'hls'}

HLS_PRESETS = (
    'ultrafast', 'superfast', 'veryfast', 'faster', 'fast',
    'medium', 'slow', 'slower', 'veryslow',
)
HLS_RANGES = {
    'concurrency': (1, 32),
    'rlimit_mb': (0, 32768),
    'x264_threads': (1, 64),
    'rc_lookahead': (0, 64),
}


def default_storage_dir():
    username = os.environ.get('SUDO_USER') or os.environ.get('USER') or Path.home().name
    return Path('/run/media') / username / 'FS-STORAGE'


def config_path(storage_root):
    return Path(storage_root) / CONFIG_FILENAME


def load_config(storage_root):
    try:
        data = json.loads(config_path(storage_root).read_text(encoding='utf-8'))
    except (OSError, json.JSONDecodeError):
        return {}
    return {key: value for key, value in data.items() if key in ALLOWED_KEYS}


def validate_hls_settings(value):
    """Validate a user-supplied 'hls' settings dict, normalising integers in place."""
    if not isinstance(value, dict):
        return False, 'hls settings must be an object'
    for key in value:
        if key not in HLS_RANGES and key != 'preset':
            return False, f'unknown hls setting: {key}'
    for key, (low, high) in HLS_RANGES.items():
        if key not in value:
            continue
        try:
            number = int(value[key])
        except (TypeError, ValueError):
            return False, f'"{key}" must be an integer'
        if not (low <= number <= high):
            return False, f'"{key}" must be between {low} and {high}'
        value[key] = number
    if 'preset' in value:
        preset = value['preset']
        if preset is None:
            preset = ''
        if not isinstance(preset, str) or (preset and preset not in HLS_PRESETS):
            return False, f'"preset" must be one of: {", ".join(HLS_PRESETS)}'
        value['preset'] = preset
    return True, ''


def save_config(storage_root, platform_name=None, storage_dir=None, hls=None):
    root = Path(storage_root)
    root.mkdir(parents=True, exist_ok=True)
    current = load_config(root)
    if platform_name is not None:
        current['platform_name'] = platform_name
    if storage_dir is not None:
        current['storage_dir'] = storage_dir
    if hls is not None:
        current['hls'] = hls
    config_path(root).write_text(json.dumps(current, indent=2), encoding='utf-8')
    return current


def discover_storage_roots(extra=None):
    roots = []
    if extra:
        for raw in extra:
            if raw:
                roots.append(Path(raw))
    roots.append(default_storage_dir())
    for raw in [
        '/run/media',
        '/mnt/data',
        '/mnt',
        '/media',
    ]:
        roots.append(Path(raw))
    folded = []
    for root in roots:
        if root in folded:
            continue
        folded.append(root)
        if not root.is_dir():
            continue
        try:
            usage = shutil.disk_usage(root)
            free = usage.free
        except OSError:
            free = 0
        yield {
            'path': str(root),
            'exists_schema': (root / 'storage').is_dir(),
            'writable': os.access(root, os.W_OK),
            'free_bytes': free,
        }


def validate_storage_dir(path):
    candidate = Path(str(path)).expanduser()
    if not candidate.is_dir():
        return False, 'Path is not an existing directory'
    if not os.access(candidate, os.W_OK):
        return False, 'Directory is not writable'
    if not (candidate / 'storage').is_dir() and any(candidate.iterdir()):
        return False, 'Directory must be empty or already contain a Filey storage layout'
    return True, ''