class Settings {
    constructor(){
        this.element = document.createElement('div');
        this.element.className = 'settings';
        this.onSaveName = null;
        this.onSaveStorage = null;
        this.onPrefsChange = null;
        this.onSaveHls = null;
        this.createNameSection();
        this.createStorageSection();
        this.createHlsSection();
        this.createPrefsSection();
    }

    createNameSection(){
        const field = document.createElement('section');
        field.className = 'settings-card';

        const h2 = document.createElement('h2');
        h2.textContent = 'Platform';

        const hint = document.createElement('p');
        hint.className = 'settings-hint';
        hint.textContent = 'A display name used across the whole platform, shared by every client.';

        const row = document.createElement('div');
        row.className = 'settings-row';
        const label = document.createElement('label');
        label.htmlFor = 'settings-name';
        label.textContent = 'Platform name';
        this.nameInput = document.createElement('input');
        this.nameInput.id = 'settings-name';
        this.nameInput.type = 'text';
        this.nameInput.maxLength = 40;
        this.nameInput.placeholder = 'Filey';
        const save = document.createElement('button');
        save.type = 'button';
        save.className = 'settings-btn';
        save.textContent = 'Save name';
        save.addEventListener('click', () => {
            const value = this.nameInput.value.trim();
            if (value && this.onSaveName) this.onSaveName(value);
        });
        row.append(label, this.nameInput, save);

        this.nameMsg = document.createElement('p');
        this.nameMsg.className = 'settings-msg';
        field.append(h2, hint, row, this.nameMsg);
        this.element.appendChild(field);
    }

    createStorageSection(){
        const field = document.createElement('section');
        field.className = 'settings-card';

        const h2 = document.createElement('h2');
        h2.textContent = 'Storage';

        const hint = document.createElement('p');
        hint.className = 'settings-hint';
        hint.textContent = 'Where files live. Changing this requires a server restart to take effect.';

        this.storageList = document.createElement('div');
        this.storageList.className = 'settings-storage-list';

        this.customInput = document.createElement('input');
        this.customInput.type = 'text';
        this.customInput.placeholder = 'Custom path like /mnt/data ...';
        this.customInput.classList.add('settings-custom');

        const save = document.createElement('button');
        save.type = 'button';
        save.className = 'settings-btn';
        save.textContent = 'Save storage';
        save.addEventListener('click', () => {
            const selected = this.selectedStorage();
            if (selected && this.onSaveStorage){
                this.onSaveStorage(selected, this.nameInput.value.trim());
            }
        });

        const customRow = document.createElement('div');
        customRow.className = 'settings-row';
        customRow.append(this.customInput, save);

        this.storageMsg = document.createElement('p');
        this.storageMsg.className = 'settings-msg';

        field.append(h2, hint, this.storageList, customRow, this.storageMsg);
        this.element.appendChild(field);
    }

    createHlsSection(){
        const field = document.createElement('section');
        field.className = 'settings-card';

        const h2 = document.createElement('h2');
        h2.textContent = 'Transcoding / HLS';

        const hint = document.createElement('p');
        hint.className = 'settings-hint';
        hint.textContent = 'Caps on the on-demand conversion workers. Changes apply to the next conversion — no server restart needed.';

        const grid = document.createElement('div');
        grid.className = 'settings-prefs';

        this.hlsConcurrency = this.fieldInput('settings-hls-concurrency', 'Max concurrent conversions', 'number');
        this.hlsRlimit = this.fieldInput('settings-hls-rlimit', 'Memory cap per conversion (MB, 0 = off)', 'number');
        this.hlsThreads = this.fieldInput('settings-hls-threads', 'x264 threads (CPU fallback)', 'number');
        this.hlsLookahead = this.fieldInput('settings-hls-lookahead', 'x264 lookahead (frames)', 'number');

        const presetLabel = document.createElement('label');
        presetLabel.className = 'settings-field';
        presetLabel.htmlFor = 'settings-hls-preset';
        const presetSpan = document.createElement('span');
        presetSpan.textContent = 'x264 preset';
        this.hlsPreset = document.createElement('select');
        this.hlsPreset.id = 'settings-hls-preset';
        presetLabel.append(presetSpan, this.hlsPreset);

        grid.append(this.hlsConcurrency, this.hlsRlimit, this.hlsThreads, this.hlsLookahead, presetLabel);

        const save = document.createElement('button');
        save.type = 'button';
        save.className = 'settings-btn';
        save.textContent = 'Save transcoding';
        save.addEventListener('click', () => {
            if (this.onSaveHls) this.onSaveHls(this.collectHls());
        });

        this.hlsMsg = document.createElement('p');
        this.hlsMsg.className = 'settings-msg';

        field.append(h2, hint, grid, save, this.hlsMsg);
        this.element.appendChild(field);
    }

    createPrefsSection(){
        const field = document.createElement('section');
        field.className = 'settings-card';

        const h2 = document.createElement('h2');
        h2.textContent = 'Your defaults (this browser)';

        const hint = document.createElement('p');
        hint.className = 'settings-hint';
        hint.textContent = 'Saved locally and applied next time you open the library.';

        const grid = document.createElement('div');
        grid.className = 'settings-prefs';

        const viewLabel = this.fieldSelect('settings-pref-view', 'View', ['grid', 'list']);
        const pageLabel = this.fieldSelect('settings-pref-page', 'Items per page', ['12', '24', '48', '96']);
        const sortLabel = this.fieldSelect('settings-pref-sort', 'Sort', [
            ['default', 'Recent first'],
            ['oldest', 'Oldest first'],
            ['name_asc', 'Name A-Z'],
            ['name_desc', 'Name Z-A'],
            ['size_desc', 'Largest first'],
            ['size_asc', 'Smallest first'],
            ['type', 'Type'],
        ]);

        this.viewSelect = viewLabel.querySelector('select');
        this.pageSelect = pageLabel.querySelector('select');
        this.sortSelect = sortLabel.querySelector('select');

        for (const select of [this.viewSelect, this.pageSelect, this.sortSelect]){
            select.addEventListener('change', () => {
                if (this.onPrefsChange) this.onPrefsChange(this.collectPrefs());
            });
        }

        grid.append(viewLabel, pageLabel, sortLabel);
        field.append(h2, hint, grid);
        this.element.appendChild(field);
    }

    fieldSelect(id, caption, options){
        const label = document.createElement('label');
        label.className = 'settings-field';
        label.htmlFor = id;
        const span = document.createElement('span');
        span.textContent = caption;
        const select = document.createElement('select');
        select.id = id;
        for (const option of options){
            const opt = document.createElement('option');
            if (Array.isArray(option)){
                opt.value = option[0];
                opt.textContent = option[1];
            } else {
                opt.value = option;
                opt.textContent = option;
            }
            select.appendChild(opt);
        }
        label.append(span, select);
        return label;
    }

    fieldInput(id, caption, type = 'text'){
        const label = document.createElement('label');
        label.className = 'settings-field';
        label.htmlFor = id;
        const span = document.createElement('span');
        span.textContent = caption;
        const input = document.createElement('input');
        input.type = type;
        input.id = id;
        if (type === 'number'){
            input.step = '1';
            input.inputMode = 'numeric';
        }
        label.append(span, input);
        return label;
    }

    setData({ platform_name, storage_dir, candidates, hls } = {}){
        if (platform_name !== undefined){
            this.nameInput.value = platform_name;
            this.nameMsg.textContent = '';
        }
        this.storageList.textContent = '';
        let matched = false;
        (Array.isArray(candidates) ? candidates : []).forEach((candidate) => {
            const label = document.createElement('label');
            label.className = 'settings-radio';
            const radio = document.createElement('input');
            radio.type = 'radio';
            radio.name = 'settings-storage';
            radio.dataset.path = candidate.path;
            label.append(radio);
            const span = document.createElement('span');
            span.textContent = candidate.path;
            label.appendChild(span);
            const meta = document.createElement('small');
            const flags = [];
            if (candidate.exists_schema) flags.push('valid layout');
            flags.push(candidate.writable ? 'writable' : 'read-only');
            meta.textContent = flags.join(' · ');
            label.appendChild(meta);
            if (storage_dir && candidate.path === storage_dir){
                radio.checked = true;
                matched = true;
            }
            this.storageList.appendChild(label);
        });
        if (!matched && storage_dir){
            this.customInput.value = storage_dir;
        }
        if (hls) this.setHls(hls);
    }

    setHls({ values, defaults, limits, presets } = {}){
        limits = limits || {};
        this.hlsPreset.textContent = '';
        const defaultOption = document.createElement('option');
        defaultOption.value = '';
        defaultOption.textContent = `Default (${(defaults && defaults.preset) || 'current'})`;
        this.hlsPreset.appendChild(defaultOption);
        (Array.isArray(presets) ? presets : []).forEach((preset) => {
            const option = document.createElement('option');
            option.value = preset;
            option.textContent = preset;
            this.hlsPreset.appendChild(option);
        });

        this.hlsConcurrencyInput = this.hlsConcurrency.querySelector('input');
        this.hlsRlimitInput = this.hlsRlimit.querySelector('input');
        this.hlsThreadsInput = this.hlsThreads.querySelector('input');
        this.hlsLookaheadInput = this.hlsLookahead.querySelector('input');

        const apply = (input, key) => {
            if (!input) return;
            const range = limits[key];
            if (Array.isArray(range) && range.length === 2){
                input.min = String(range[0]);
                input.max = String(range[1]);
            }
            if (values && Number.isFinite(values[key])){
                input.value = String(values[key]);
            }
        };
        apply(this.hlsConcurrencyInput, 'concurrency');
        apply(this.hlsRlimitInput, 'rlimit_mb');
        apply(this.hlsThreadsInput, 'x264_threads');
        apply(this.hlsLookaheadInput, 'rc_lookahead');
        if (values && typeof values.preset === 'string'){
            this.hlsPreset.value = values.preset;
        }
        this.setHlsStatus('');
    }

    collectHls(){
        const valueOf = (label, fallback) => {
            const input = label && label.querySelector('input');
            const value = input ? Number(input.value) : NaN;
            return Number.isFinite(value) ? value : fallback;
        };
        return {
            concurrency: valueOf(this.hlsConcurrency, 2),
            rlimit_mb: valueOf(this.hlsRlimit, 4096),
            x264_threads: valueOf(this.hlsThreads, 4),
            rc_lookahead: valueOf(this.hlsLookahead, 24),
            preset: this.hlsPreset ? this.hlsPreset.value : ''
        };
    }

    setHlsStatus(message, kind = 'ok'){
        this.hlsMsg.textContent = message || '';
        this.hlsMsg.classList.toggle('error', kind === 'error');
    }

    selectedStorage(){
        for (const radio of this.storageList.querySelectorAll('input[type=radio]')){
            if (radio.checked) return radio.dataset.path;
        }
        const custom = this.customInput.value.trim();
        return custom || null;
    }

    setPrefs({ sort, perPage, view } = {}){
        if (this.sortSelect.value !== sort) this.sortSelect.value = sort;
        if (this.pageSelect.value !== String(perPage)) this.pageSelect.value = String(perPage);
        if (this.viewSelect.value !== view) this.viewSelect.value = view;
    }

    collectPrefs(){
        return {
            sort: this.sortSelect.value,
            perPage: Number(this.pageSelect.value),
            view: this.viewSelect.value,
        };
    }

    setStatus(message, kind = 'ok'){
        this.storageMsg.textContent = message || '';
        this.storageMsg.classList.toggle('error', kind === 'error');
    }

    setStorageStatus(message, kind = 'ok'){
        this.setStatus(message, kind);
    }

    setNameStatus(message, kind = 'ok'){
        this.nameMsg.textContent = message || '';
        this.nameMsg.classList.toggle('error', kind === 'error');
    }

    render(target = null){
        if (target) target.appendChild(this.element);
        return this;
    }
}