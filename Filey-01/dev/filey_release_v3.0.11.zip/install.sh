#!/bin/bash
# Filey installer for Debian/Ubuntu systems.
# Run as root (or via sudo). Interactively asks for install preferences,
# installs system dependencies, sets up a Python virtualenv and an
# optional systemd service.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
APP_SRC="$SCRIPT_DIR/app"

if [[ $EUID -ne 0 ]]; then
    echo "This installer must be run as root, e.g.: sudo ./install.sh" >&2
    exit 1
fi

if [[ ! -d "$APP_SRC" ]]; then
    echo "Cannot find application files at $APP_SRC (expected alongside install.sh)." >&2
    exit 1
fi

echo "=================================================="
echo " Filey installer"
echo "=================================================="
echo

ask() {
    # ask <prompt> <default> -> echoes the answer
    local prompt="$1" default="$2" reply
    read -r -p "$prompt [$default]: " reply || true
    echo "${reply:-$default}"
}

ask_yn() {
    # ask_yn <prompt> <default: y|n> -> echoes y or n
    local prompt="$1" default="$2" reply
    while true; do
        read -r -p "$prompt [$default]: " reply || true
        reply="${reply:-$default}"
        case "$reply" in
            [Yy]*) echo "y"; return ;;
            [Nn]*) echo "n"; return ;;
            *) echo "Please answer y or n." >&2 ;;
        esac
    done
}

DEFAULT_USER="${SUDO_USER:-filey}"

INSTALL_DIR=$(ask "Installation directory" "/opt/filey")
SERVICE_USER=$(ask "System user to run Filey as" "$DEFAULT_USER")
DEFAULT_STORAGE="/run/media/$SERVICE_USER/FS-STORAGE"
STORAGE_DIR=$(ask "Media storage directory (created if missing)" "$DEFAULT_STORAGE")
PLATFORM_NAME=$(ask "Platform display name" "Filey")
PORT=$(ask "Port to serve on" "9100")
ENABLE_SERVICE=$(ask_yn "Install as a systemd service (auto-start on boot)?" "y")
START_NOW=$(ask_yn "Start Filey now after installation?" "y")

echo
echo "--- Summary ---"
echo "Install directory : $INSTALL_DIR"
echo "Run as user       : $SERVICE_USER"
echo "Storage directory : $STORAGE_DIR"
echo "Platform name     : $PLATFORM_NAME"
echo "Port              : $PORT"
echo "Systemd service   : $ENABLE_SERVICE"
echo "Start now         : $START_NOW"
echo
CONFIRM=$(ask_yn "Proceed with installation?" "y")
if [[ "$CONFIRM" != "y" ]]; then
    echo "Installation aborted."
    exit 0
fi

if ! id "$SERVICE_USER" &>/dev/null; then
    echo ">> Creating system user '$SERVICE_USER'"
    useradd --system --create-home --shell /usr/sbin/nologin "$SERVICE_USER"
fi

echo ">> Granting GPU (VAAPI) device access to '$SERVICE_USER'"
for grp in render video; do
    if getent group "$grp" &>/dev/null; then
        usermod -aG "$grp" "$SERVICE_USER"
    fi
done

echo ">> Installing system dependencies (python3, venv, pip, ffmpeg)"
apt-get update -y
apt-get install -y python3 python3-venv python3-pip ffmpeg

echo ">> Copying application files to $INSTALL_DIR"
mkdir -p "$INSTALL_DIR"
cp -a "$APP_SRC/." "$INSTALL_DIR/"

echo ">> Creating Python virtual environment"
python3 -m venv "$INSTALL_DIR/.venv"
"$INSTALL_DIR/.venv/bin/pip" install --upgrade pip
"$INSTALL_DIR/.venv/bin/pip" install -r "$INSTALL_DIR/requirements.txt"

echo ">> Preparing storage directory $STORAGE_DIR"
mkdir -p "$STORAGE_DIR"
cat > "$STORAGE_DIR/.filey-config.json" <<EOF
{
  "platform_name": "$PLATFORM_NAME",
  "storage_dir": "$STORAGE_DIR"
}
EOF

chown -R "$SERVICE_USER:$SERVICE_USER" "$INSTALL_DIR" "$STORAGE_DIR"

echo ">> Writing environment file /etc/filey/filey.env"
mkdir -p /etc/filey
cat > /etc/filey/filey.env <<EOF
FILEY_PORT=$PORT
FILEY_STORAGE_DIR=$STORAGE_DIR
# Optional HLS transcoding defaults (the in-app Transcoding / HLS
# settings under .filey-config.json override these when set):
#FS_HLS_CONCURRENCY=2
#FS_HLS_RLIMIT_MB=4096
#FS_X264_THREADS=4
#FS_X264_LOOKAHEAD=24
#FS_X264_PRESET=
EOF
chmod 640 /etc/filey/filey.env
chown root:"$SERVICE_USER" /etc/filey/filey.env

cat > /etc/filey/install.conf <<EOF
INSTALL_DIR=$INSTALL_DIR
SERVICE_USER=$SERVICE_USER
STORAGE_DIR=$STORAGE_DIR
EOF

chmod +x "$INSTALL_DIR/start.sh" "$INSTALL_DIR/stop.sh"

if [[ "$ENABLE_SERVICE" == "y" ]]; then
    echo ">> Installing systemd service"
    cat > /etc/systemd/system/filey.service <<EOF
[Unit]
Description=Filey media platform
After=network.target

[Service]
Type=simple
User=$SERVICE_USER
Group=$SERVICE_USER
WorkingDirectory=$INSTALL_DIR
EnvironmentFile=/etc/filey/filey.env
ExecStart=$INSTALL_DIR/.venv/bin/python3 $INSTALL_DIR/server.py
Restart=on-failure
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF
    systemctl daemon-reload
    systemctl enable filey.service
    if [[ "$START_NOW" == "y" ]]; then
        systemctl restart filey.service
        echo ">> Filey service started. Check status with: systemctl status filey"
    else
        echo ">> Service enabled but not started. Start it with: systemctl start filey"
    fi
else
    echo ">> Skipping systemd service setup."
    if [[ "$START_NOW" == "y" ]]; then
        echo ">> Starting Filey directly (foreground)."
        sudo -u "$SERVICE_USER" env FILEY_PORT="$PORT" FILEY_STORAGE_DIR="$STORAGE_DIR" "$INSTALL_DIR/start.sh" &
        echo ">> Filey launched in background (PID $!). Use $INSTALL_DIR/stop.sh to stop it."
    fi
fi

echo
echo "=================================================="
echo " Installation complete."
echo " Access Filey at: http://<this-machine-ip>:$PORT"
echo "=================================================="
